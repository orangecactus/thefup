<?php
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_image_slider.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_filterable_portfolio.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_calltoaction.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_service.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_pricing_table.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_social.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_header_subheader.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_skill.php' );
require_once( plugin_dir_path( __FILE__ ) . '/visual_composer/vc_team.php' );